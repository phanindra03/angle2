export class Department{
    dId:number;
    dName:string;
    

}